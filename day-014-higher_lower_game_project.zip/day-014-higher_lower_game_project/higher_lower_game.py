from game_data import data
import random
from art import logo, vs
from replit import clear

# diplay logo
print(logo)
# 2 random item from list data

def select_data():
    random_items = random.choice(data)
    data.remove(random_items)
    return random_items

def format_data(data):
   return f"{data['name']}, {data['description']}, from {data['country']}"


def game():
    data_A = select_data()
    data_B = select_data()
    score = 0

    while(len(data) > 0):
          print(f"who has more followers: A: {data_A['name']} or B: {data_B['name']}?")
          
          
          print(f"a: {data_A['name']}, {data_A['follower_count']}")
          print(f"b: {data_B['name']}, {data_B['follower_count']}")

          user_answer = input().lower

          if(data_A['follower_count'] > data_B['follower_count']):
                    if(user_answer == 'a'):
                              score = score+1
                              data_A = data_B
                              data_B = select_data()
                    else:
                              print(f"wrong answer, end of the game. Your score: {score}")
                              return 0
          else:
                    if(user_answer == 'b'):
                              score = score + 1
                              data_B = data_A
                              data_A = select_data()
                    else:
                              print(f"wrong answer, end of the game, Your score: {score}")
                              return 0
    
    
game()

#     print(vs)
#     data_B = select_data()
#     print(f"Comare A: {data_B['name']}, {data_B['description']}, from {data_B['country']}")

#     user_select = input("Who has more followers? Type 'A' or 'B': ").lower()
    
#     if user_select == "a" and data_A['follower_count'] > data_B['follower_count']:
#         return data_A
#     elif user_select == "b" and data_B['follower_count'] > data_A['follower_count']:
#         return data_B
#     else:
#         print("wrogn anwser")




#print(compare_data())
#     pass

# print(len(data))

# print(select_data())
# print(len(data))
# print(len(data))
# print(select_data())
# print(len(data))
